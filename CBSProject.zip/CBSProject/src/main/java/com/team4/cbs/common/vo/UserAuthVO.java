package com.team4.cbs.common.vo;

import lombok.Data;

@Data
public class UserAuthVO {
	private String auth;
	private String userCd;

}
