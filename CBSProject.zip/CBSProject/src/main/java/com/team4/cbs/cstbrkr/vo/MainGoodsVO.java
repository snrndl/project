package com.team4.cbs.cstbrkr.vo;

import lombok.Data;

@Data
public class MainGoodsVO {
	private int goodsNo;
	private String cstmrCd;
}
