package com.team4.cbs.cstbrkr.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class TaxItemVO {
	
	private int taxIemNo;
	private String taxIemNm;
	
}
