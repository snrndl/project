package com.team4.cbs.cstbrkr.vo;

import lombok.Data;

@Data
public class LegalPersonVO {
	private String cprCstmrCd;		//법인고객코드
	private String cprNo;			//법인번호
}
