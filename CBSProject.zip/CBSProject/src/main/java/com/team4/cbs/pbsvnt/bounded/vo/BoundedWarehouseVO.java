package com.team4.cbs.pbsvnt.bounded.vo;

import lombok.Data;

@Data
public class BoundedWarehouseVO {
	private String entrManageNo;
	private String bndwasCd;
	private String bndwasZone;
	private int bndwasNo;
}
