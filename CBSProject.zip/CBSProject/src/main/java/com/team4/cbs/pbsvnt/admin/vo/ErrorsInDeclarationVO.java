package com.team4.cbs.pbsvnt.admin.vo;

import java.util.Date;

import lombok.Data;

@Data
public class ErrorsInDeclarationVO {
	private String erordecNo;
	private String thngNo;
	private Date erordecDe;
	private String aplcnt;
	private String erordecCn;
}
