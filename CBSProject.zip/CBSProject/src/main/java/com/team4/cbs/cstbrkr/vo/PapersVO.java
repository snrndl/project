package com.team4.cbs.cstbrkr.vo;

import lombok.Data;

@Data
public class PapersVO {
	private String papersIemCd;	//서류 항목 코드
	private String papersSE;	//서류 구분
}
