package com.team4.cbs.cstbrkr.vo;

import lombok.Data;

@Data
public class IndividualPersonVO {
	private String indvdlBsnmCstmrCd;
}
